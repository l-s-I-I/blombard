<?php

$servername = "localhost";
$username = "ueemzcqw_wow";
$password = "pYQKXxuzPKpPvpkCLSgb";
$dbname = "ueemzcqw_wow";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>